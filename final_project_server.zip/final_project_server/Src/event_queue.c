#include "event_queue.h"
#include "cycle_buffer.h"
#include "usart2.h"
#include "button.h"
#include "usart1.h"
#include "stm32f303xe.h"
#include "terminal.h"


uint8_t * eventQ ;
cbuf_handle_t HeventQ;

void eventQueueInit(){
	 eventQ = (uint8_t *) malloc(EVENT_BUFFER_SIZE * sizeof(uint8_t));
	HeventQ = cycleBufInit(eventQ, EVENT_BUFFER_SIZE);

}

void addEvent(EVENT event){
	cycleBufPush(HeventQ,event);

}


void eventProcess(){
	EVENT event;
	if(cycleBufPop(HeventQ, &event)==0){
	switch (event){
					case EVENT_USART1 :
						usart1EventHandler();
						break;
					case EVENT_BUTTON:
						btnEventHandle();
						break;
					case EVENT_USART2:
						usart2EventHandler();
					default:
						return;
	}
	}
}
