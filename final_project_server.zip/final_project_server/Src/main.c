/*****************************************************************************//*
    Created By : Abdallah Natsheh , Ameer Haddad
    Server Final Project
*//*****************************************************************************/
#include "stm32f303xe.h"
#include "usart1.h"
#include "usart2.h"
#include "esp8266.h"
#include "types.h"
#include "button.h"
#include "led.h"
#include "event_queue.h"
#include "iwdg.h"
#include "terminal.h"
#include "timer2.h"
#include "scheduler.h"



int main(void)
{
	char  ssid[32];
	char  passwd[64];
	USART2_Init();
	USART1_Init();
	USART2_print("Welcome to my server!\n\n");
	 //wait 15 sec to enter ssid
	iwdg_init(IWDG_PR_DIV_256,3349999);
	setSSID(ssid);
    iwdg_feed();
	//wait 15 sec to enter password
	setPASSWD(passwd);
    iwdg_feed();

	eventQueueInit();
	NVIC_EnableIRQ(USART2_IRQn);
	//WAIT NEARLY 22 SECOND THEN RESTART big preloader for the long time to wait
	iwdg_init(IWDG_PR_DIV_256,3349999);

	espInit(ssid,passwd);
    LED_init();
    BUTTON_init();
    TIMER2_init(1);

    while (1){
    	eventProcess();
        iwdg_feed();
        if(USART2_commandReceived())
        {
            TERMINAL_handleCommand();
        }

        if(USART1_commandReceived())
        {
            TERMINAL_handleCommand();
        }
        if(TIMER2_expired())
        {
        	SCHEDULER_handle();
        }
    };
}

