#include "button.h"
#include "stm32f303xe.h"
#include "types.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "usart1.h"
#include "usart2.h"
#include "event_queue.h"
#include "esp8266.h"


//static int Pressed = FALSE;
EVENT event = EVENT_BUTTON;



void BUTTON_init(void)
{
	 // Enable GPIOA and GPIOC clocks.
	    RCC->AHBENR |= 0x000A0000;
	    // Enable the SYSCFG clock. This is necessary for connecting PC13 to EXTI13.
	    RCC->APB2ENR |= 0x00000001;
	    // Configure PA5 as output
	    // (by default it will then be push pull, see p. 237 of the reference manual).
	    GPIOA->MODER |= 0x00000400;
	    // PA13 is the push button. No need to configure it, because by default it's an input.

	    // Configure EXTI(extended interrupt) 13, to which PC13 can be connected:
	    // Connect PC13 to EXTI13. See p. 252 of the reference manual.
	    // Note that the reference manual counts the registers beginning with EXTICR from
	    // 1 to 4,
	    // while the h-file stm32f303xe.h defines the registers as an array of size 4.
	    // So EXTICR4 in the reference manual is EXTICR[3] in the program.
	    SYSCFG->EXTICR[3] |= 0x00000020;
	    // Set EXTI13 to be triggered by a falling edge.
	    EXTI->FTSR |= 0x00002000;
	    // Enable EXTI13.
	    EXTI->IMR |= 0x00002000;
	    // Enable the interrupt handler for EXTI13.
	    NVIC_EnableIRQ(EXTI15_10_IRQn);

}


void btnEventHandle(){

	SERVER_handleButton();
	//USART2_print("button event ");
}


void EXTI15_10_IRQHandler(void)
{
	EXTI->PR |= 0x00002000;
    // Reset the interrupt request flag.
	//EXTI->PR |= 0x00002000;
    //Pressed = TRUE;
     addEvent(event);

}
