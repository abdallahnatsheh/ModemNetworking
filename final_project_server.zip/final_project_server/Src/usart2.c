#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "stm32f303xe.h"
#include "usart1.h"
#include "usart2.h"
#include "cycle_buffer.h"
#include "types.h"
#include "event_queue.h"



//static char A_Rx_Buffer[128];
// This cycle buffer is used to receive commands from the user
 uint8_t * A_Rx_Buffer ;
cbuf_handle_t H_Rx_Buffer;
// This cycle buffer is used to transfer the input to esp8266
uint8_t * A_Tx_Buffer ;
cbuf_handle_t H_Tx_Buffer ;
//flag to check if a command received
static BOOL Command_Received= FALSE;;
EVENT usaerEvent1 = EVENT_USART2;
//static char A_Tx_Buffer[128];

//static char *P_Loc_In_Rx_Buffer = A_Rx_Buffer;
//static char * const P_End_Of_Rx_Buffer = A_Tx_Buffer + 128 - 1;

BOOL USART2_commandReceived(void)
{
    if(Command_Received){
    	Command_Received = FALSE;
    	return TRUE;
    }
    else{
    	return FALSE;
    }
}
void usart2EventHandler(){
	uint8_t rx_byte;
		// Read the received byte into the buffer.
		// This also clears the interrupt request flag.
    rx_byte = USART2->RDR;

	    // If the user entered '\n', a whole command has been received.
	    if(rx_byte == '\n')
	    {
	    	Command_Received = TRUE;
	      cycleBufPush(H_Rx_Buffer,rx_byte);

	    	return;
	    }
	    cycleBufPush(H_Rx_Buffer,rx_byte);
}

int USART2_getCommand(char *string)
{
	int so_far =0;
	int len = strlen (string)-1;
	int counter=0;
	int limit = UART_BUFFER_SIZE;
	while(so_far < len && counter<limit){
		if ((int)A_Rx_Buffer[counter] != string[so_far])
			{
				so_far =0;
				counter++;
			}
		else{
			so_far++;
			counter++;
		}
	}
	if (so_far == len) {
		return 1;
	}
	else{

		return -1;
	}
}


void USART2_EXTI26_IRQHandler(void)
{
    addEvent(usaerEvent1);
	eventProcess();
}




// initialize USART2
void USART2_Init(void)
{
	  // Enable GPIOA clock (p. 148 in the datasheet).
	    RCC->AHBENR |= 0x00020000;
	    // Enable USART2 clock.
	    RCC->APB1ENR |= 0x00020000;
	    // Configure GPIOA pins 2 and 3 as alternate function 7, which is USART2.
	    GPIOA->MODER |= 0x000000A0;
	    // AFR[0] is the same as AFRL in the reference manual (p. 241),
	    // and AFR[1] is the same as AFRH in the reference manual (p. 242).
	    GPIOA->AFR[0] |= 0x00007700;
	    //USART2->BRR = 69;  // 8 MHz / 115200 baud rate. for debug only
	    USART2->BRR = 833;  // 8 MHz / 9600 baud rate.

	    // Enable USART2 and its RX and TX functionality.
	    // Also enable the RX interrupt.
	    USART2->CR1 = 0x0000002D;
	    NVIC_EnableIRQ(USART2_IRQn);  				// enable interrupt
	    A_Rx_Buffer = (uint8_t *) malloc(UART_BUFFER_SIZE * sizeof(uint8_t));
	    H_Rx_Buffer = cycleBufInit(A_Rx_Buffer, UART_BUFFER_SIZE);

	    A_Tx_Buffer  = malloc(UART_BUFFER_SIZE * sizeof(uint8_t));
	    H_Tx_Buffer = cycleBufInit(A_Tx_Buffer, UART_BUFFER_SIZE);

}

void USART2_printCharacter(char c)
{
    USART2->TDR = c;
    while(!(USART2->ISR & 0x00000080));
}




void USART2_print(const char *p_data)
{
	while(*p_data != '\0')
	{
		USART2->TDR = *p_data;
        p_data++;
        while(!(USART2->ISR & 0x00000080));
	}
}
