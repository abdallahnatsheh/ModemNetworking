#include "esp8266.h"
#include "timer2.h"
#include "event_queue.h"

 int countSituation = 0;
char ssid_temp[20]="";
char passwd_temp[20]="";


void espInit(char *ssid,char *passwd){

	char commands[ESP_SIZE_OF_COMMAND_BUFFER]; //array for commands

	/********* AT **********/
	USART1_print("AT\r\n");
	for(int c=0;c<1000000;c++);
	if(Wait_for2("AT\r\r\n\r\nOK\r\n")==1){
		USART2_print("AT---->OK\n\n");
	}



		/********* AT+CIPCLOSE **********/
		USART1_print("AT+CIPCLOSE=5\r\n");
		for(int c=0;c<1000000;c++);
		if(Wait_for2("OK\r\n")==1){
			USART2_print("CIPCLOSE-->OK\n\n");
		}else{
			USART2_print("CIPCLOSE-->No one Connected\n\n");
		}

	/********* AT+CWMODE=1 **********/
	USART1_print("AT+CWMODE=1\r\n");
	for(int c=0;c<1000000;c++);
	if (Wait_for2("AT+CWMODE=1\r\r\n\r\nOK\r\n")==1){
		USART2_print("CW MODE---->OK\n\n");
		}


	/********* AT+CWJAP="SSID","PASSWD" **********/
	if( !(strlen(ssid)<=1) || !(strlen(passwd)<=1) ){
	USART2_print("connecting... to the provided AP\n");
	sprintf (commands,"AT+CWJAP=\"%s\",\"%s\"\r\n", ssid, passwd);
	USART1_print(commands);
	for(int c=0;c<7000000;c++);
	if (Wait_for2("WIFI GOT IP\r\n\r\nOK\r\n")==1){
		 memset(commands, 0, ESP_SIZE_OF_COMMAND_BUFFER);
						 sprintf (commands, "Connected to,\"%s\"\n\n", ssid);
						 USART2_print(commands);
			}
			else{
				USART2_print("Connection Error\n\n");
			}
		}
	else{
		USART2_print("connecting... to the previous AP\n");
	}

	/********* AT+CIPMUX=1 **********/

	USART1_print("AT+CIPMUX=1\r\n");
	for(int c=0;c<1000000;c++);
	if (Wait_for2("OK\r\n")==1){
		USART2_print("CIPMUX---->OK\n\n");
			}
			else{
				USART2_print("CIPMUX---->ERROR\n\n");
			}
	/********* AT+CIPSERVER=1,80 **********/

	USART1_print("AT+CIPSERVER=1,80\r\n");
	while (Wait_for2("OK\r\n")!=1){
		for(int c=0;c<3000000;c++);
				}
	USART2_print("CIPSERVER---->OK\n\n");


	/********* AT+CIFSR ***********/
	USART1_print("AT+CIFSR\r\n");
	for(int c=0;c<1000000;c++);
	if (Wait_for("CIFSR:STAIP,\"")==1){
		getIp();
			}
	else{
		USART2_print("IPSERVER---->ERROR\n\n");
			}
	USART2_print("Now Your Ready To Go !\n\n");


}
void Server_Send (char *str)
{
	int len = strlen (str);
	char data[60];
	sprintf (data, "AT+CIPSEND=%d,%d\r\n", 0, len);
	USART1_print(data);
	while (Wait_for("OK\r\n>")!=1);
	USART1_print(str);
	while (Wait_for("SEND OK")!=1);
	USART2_print("success! \r\n");
	return;
}


void SERVER_handleButton(void)
{
	countSituation++;
	 if(countSituation== 1)
	    {
	    	Server_Send("Off\r\n");
	    	USART2_print("Off! \r\n");
	    }
		else if(countSituation== 2)
	    {
	    	Server_Send("On\r\n");
	    	USART2_print("On! \r\n");
	    }
	    else if(countSituation==3)
	    {
	    	Server_Send("Blink\r\n");
	    	countSituation=0;
	    	USART2_print("Blink! \r\n");
	    }
}

void getSsid(){
	char c;
	 if((USART2->ISR & 0x00000020)){
		 c = USART2->RDR;
		 strncat(ssid_temp, &c, 1);
	 }
}

void ssidIs(char*ssid){
	//to fix /r/n that tera term add to every input
	int size = strlen(ssid_temp);
	if (ssid_temp[size - 1] == '\r' || ssid_temp[size - 1] == '\n' )
			ssid_temp[size - 1] = '\0';
	if (ssid_temp[size - 2] == '\r' || ssid_temp[size - 2] == '\n' )
			ssid_temp[size - 2] = '\0';
	strcpy(ssid,ssid_temp);
}


void getPasswd(){
	char c;
	 if((USART2->ISR & 0x00000020)){
		 c = USART2->RDR;
		 strncat(passwd_temp, &c, 1);
	 }
}

void passIs(char*pass){
	//to fix /r/n that tera term add to every input
	int size = strlen(passwd_temp);
	if (passwd_temp[size - 1] == '\r' || passwd_temp[size - 1] == '\n' )
		passwd_temp[size - 1] = '\0';
	if (passwd_temp[size - 2] == '\r' || passwd_temp[size - 2] == '\n' )
		passwd_temp[size - 2] = '\0';
	strcpy(pass,passwd_temp);
}
void setSSID(char*ssid){
	NVIC_DisableIRQ(USART2_IRQn);
	USART2_print("Enter SSID(you have just 10 sec) :\n\n");
	for(int c=0;c<3000000;c++){
		  getSsid();
	  }
	 ssidIs(ssid);

}

void setPASSWD(char*passwd){
	 USART2_print("Enter the password (you have just 10 sec) :\n\n");
		for(int c=0;c<3000000;c++){
		  getPasswd();
		  }
	  passIs(passwd);
}



