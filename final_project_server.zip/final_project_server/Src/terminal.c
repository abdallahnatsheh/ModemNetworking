#include <string.h>
#include "terminal.h"
#include "led.h"
#include "scheduler.h"
#include "usart1.h"
#include "esp8266.h"
#include "usart2.h"







void TERMINAL_handleCommand(void)
{

	if (USART2_getCommand("buddy")==1){
		USART2_print("hau hau\n\n");
		for(int c=0;c<30000000;c++);
    }
    else if (Wait_for3("+IPD,0,5:Off")==1){
    	SCHEDULER_stopBlinking();
    	LED_off();
    }
    else if (Wait_for3("+IPD,0,4:On")==1){
    	SCHEDULER_stopBlinking();
    	LED_on();

    }
    else if (Wait_for3("+IPD,0,7:Blink")==1){
    	SCHEDULER_blink();
    }
}
