#include "iwdg.h"


void iwdg_feed(void){
	IWDG->KR = 0xAAAA;
}

void iwdg_init(iwdg_prescaler prescaler,long unsigned int reload) {
  IWDG->KR = 0x5555;          //enable register access
  IWDG->PR = prescaler;      //prescaler divider
  IWDG->RLR = reload;       //value added to watchdog timer
  IWDG->KR = 0xCCCC;     //enable IWDG
  IWDG->KR = 0xAAAA;   //counter refresher
}
