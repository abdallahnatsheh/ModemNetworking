#include "stm32f303xe.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "usart1.h"
#include "usart2.h"
#include "types.h"

#ifndef ESP8266_H_
#define ESP8266_H_

/******************************************************************************
Definitions
******************************************************************************/
#define ESP_SIZE_OF_COMMAND_BUFFER 96

/******************************************************************************
Exported functions
******************************************************************************/

/******************************************************************************
espInit
Description: Initialises esp8266 as a server and connect it to the specified
wifi network
******************************************************************************/
void espInit(char *ssid,char *passwd);
/******************************************************************************
SERVER_handleButton
Description: Interact with push button to send the command to the client
to turn the led off ,on or blink
Server_Send:
Description : this funtion take the command and send it to the client using
the esp8266
******************************************************************************/
void SERVER_handleButton(void);
void Server_Send (char *str);

/******************************************************************************
setSSID
Description: take the ssid from the user without the use of interrupt
it will wait just for 10 seconds
helper functions:void getSsid , ssidIs.
input: the name of the ssid
******************************************************************************/
void setSSID(char*ssid);
void getSsid();
void ssidIs(char*ssid);

/******************************************************************************
setPASSWD
Description: take the password of the ssid  from the user without the use of
interrupt ,it will wait just for 10 seconds .
helper functions: getPasswd , passIs.
input: the password  of the ssid
******************************************************************************/
void setPASSWD(char*passwd);
void getPasswd();
void passIs(char*pass);
#endif
