
#include "types.h"

#ifndef USART1_H_
#define USART1_H_

/******************************************************************************
Definitions
******************************************************************************/
#define USART1_SIZE_OF_PRINT_BUFFER 128


/******************************************************************************
Exported functions
******************************************************************************/

/******************************************************************************
USART2_init
Description: Initializes USART1 on GPIOs PA9 and PA10,
  with a baud rate of 115200.
******************************************************************************/
void USART1_Init(void);

/******************************************************************************
Wait_for , Wait_for2
Description: Naive String Matching Algorithm check for the first match
and return 1 in success and -1 for failure , the difference between
wait_for and wait_for2 is the first one don't clear the RX cycle buffer
when there's a match ,  Wait_for3 clear when there is a match.
Input : the string you want to find it .
******************************************************************************/
int Wait_for (char *string);
int Wait_for2 (char *string);
int Wait_for3 (char *string);
/******************************************************************************
getIp
Description: look for the ip address from RX CYCLE BUFFER , after
sending AT+CIFSR to ESP8266 , then it will print it on the screen.
******************************************************************************/
void getIp();

/******************************************************************************
usart1EventHandler
Description: Handle usart1  event from event queue
******************************************************************************/
void usart1EventHandler();

/******************************************************************************
checkMatch
Description: Naive algorithm for string matching , doesnt use the cycle
buffer when looking for matching this means the tail doesn't move when
pop the characters from the rx buffer,return 1 in success and -1 for failure
Input : the string you want to find it .
******************************************************************************/
int checkMatch (char *string);

/******************************************************************************
USART2_print
Description: Prints a '\0'-terminated sequence of characters and push
them in the TX CYCLE BUFFER..
Input:
  p_data: The sequence to print .
******************************************************************************/
void USART1_print(const char *p_data);

/******************************************************************************
USART2_printCharacter
Description: Prints one character.
Input:
  c: The character to print.
******************************************************************************/
void USART1_printCharacter(char c);

/******************************************************************************
USART1_commandReceived
Description: check if there is a command received to the usart1.
******************************************************************************/

BOOL USART1_commandReceived(void);

#endif /* USART1_H_ */
