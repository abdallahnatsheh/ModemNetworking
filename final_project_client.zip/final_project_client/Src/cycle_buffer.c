#include "cycle_buffer.h"

// The definition of our cycle buffer structure is hidden from the user
struct cycle_buf_t {
	uint8_t * buffer;
	size_t head;
	size_t tail;
	size_t max; //of the buffer
	bool full;
};

//helper function to advance the pointer to the next value
static void advancePointer(cbuf_handle_t cbuf)
{

	if(cycleBufFull(cbuf))
    {
        cbuf->tail = (cbuf->tail + 1) ;

    }

	cbuf->head = (cbuf->head + 1);

	// We mark full because we will advance tail on the next time around
	cbuf->full = (cbuf->head == cbuf->tail);
}
//helper pointer to advance the tail to the next data
static void retreat_pointer(cbuf_handle_t cbuf)
{

	cbuf->full = false;
	cbuf->tail = (cbuf->tail + 1) ;

}



cbuf_handle_t cycleBufInit(uint8_t* buffer, size_t size)
{

	cbuf_handle_t cbuf = malloc(sizeof(cycle_buf_t));

	cbuf->buffer = buffer;
	cbuf->max = size;
	cycleBufReset(cbuf);


	return cbuf;
}

void cycleBufFree(cbuf_handle_t cbuf)
{
	free(cbuf);
}

void cycleBufReset(cbuf_handle_t cbuf)
{

    cbuf->head = 0;
    cbuf->tail = 0;
    cbuf->full = false;
}



void cycleBufPush(cbuf_handle_t cbuf, uint8_t data)
{

    cbuf->buffer[cbuf->head] = data;

    advancePointer(cbuf);
}

//its like  a normal push but it doesn't overwrite the event queue
int cycleBufPush2(cbuf_handle_t cbuf, uint8_t data)
{
    int r = -1;

    if(!cycleBufFull(cbuf))
    {
        cbuf->buffer[cbuf->head] = data;
        advancePointer(cbuf);
        r = 0;
    }

    return r;
}



int cycleBufPop(cbuf_handle_t cbuf, uint8_t * data)
{

    int r = -1;

    if(!cycleBufEmpty(cbuf))
    {
        *data = cbuf->buffer[cbuf->tail];
        retreat_pointer(cbuf);

        r = 0;
    }

    return r;
}

bool cycleBufEmpty(cbuf_handle_t cbuf)
{

    return (!cycleBufFull(cbuf) && (cbuf->head == cbuf->tail));
}

bool cycleBufFull(cbuf_handle_t cbuf)
{

    return cbuf->full;
}
