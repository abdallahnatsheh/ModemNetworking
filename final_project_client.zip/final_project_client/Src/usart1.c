
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "stm32f303xe.h"
#include "usart1.h"
#include "usart2.h"
#include "cycle_buffer.h"
#include "types.h"
#include "event_queue.h"
#include "terminal.h"



// This cycle buffer is used to receive commands from esp8266
uint8_t * A_Rx_Buffer ;
cbuf_handle_t H_Rx_Buffer;
// This cycle buffer is used to receive the transfered commands to  esp8266.
uint8_t * A_Tx_Buffer ;
cbuf_handle_t H_Tx_Buffer ;
//flag to check if a command received
static BOOL Command_Received= FALSE;;
EVENT usaerEvent = EVENT_USART1;





BOOL USART1_commandReceived(void)
{
    if(Command_Received){
    	Command_Received = FALSE;
    	return TRUE;
    }
    else{
    	return FALSE;
    }
}

void usart1EventHandler(){
	uint8_t rx_byte;
		// Read the received byte into the buffer.
		// This also clears the interrupt request flag.
	    rx_byte = USART1->RDR;

	    // If the user entered '\n', a whole command has been received.
	    if(rx_byte == '\n')
	    {
	    	Command_Received = TRUE;
			for(int c=0;c<10;c++);
	        //USART2_printCharacter(rx_byte); for debug only
	        cycleBufPush(H_Rx_Buffer,rx_byte);

	    	return;
	    }

	    cycleBufPush(H_Rx_Buffer,rx_byte);
		for(int c=0;c<10;c++);

	   //USART2_printCharacter(rx_byte); for debug only
}

//Add the revived event to the event queue using the interrupt
void USART1_EXTI25_IRQHandler(void){
    addEvent(usaerEvent);
	eventProcess();
}


// initialize USART1
void USART1_Init(void)
{
    RCC->APB2ENR |= 0x00004000;                 // enable USART1 clock
    GPIOA->AFR[1] |= 0x00000770;                // set AF1 to PA9, PA10
    GPIOA->MODER |= 0x00280000;             // define GPIO modes to alternate function for PA9, PA10
    USART1->BRR = 69;                       	     // set the baud rate, 115200 @ 8MHz
    USART1->CR1 = 0x0000002C;               // enable te, re, and rx interrupt
    USART1->CR1 |= 0x00000001;             // enable ue
    NVIC_EnableIRQ(USART1_IRQn);  		 // enable interrupt

    A_Rx_Buffer = (uint8_t *) malloc(UART_BUFFER_SIZE * sizeof(uint8_t));
    H_Rx_Buffer = cycleBufInit(A_Rx_Buffer, UART_BUFFER_SIZE);

    A_Tx_Buffer  = malloc(UART_BUFFER_SIZE * sizeof(uint8_t));
    H_Tx_Buffer = cycleBufInit(A_Tx_Buffer, UART_BUFFER_SIZE);
}

// write one character via USART1
void USART1_printCharacter(char c)
{
    USART1->TDR = c;
    while(!(USART1->ISR & 0x00000080));
}

void USART1_print(const char *p_data)
{
	while(*p_data != '\0')
	{
		USART1->TDR = *p_data;
		cycleBufPush(H_Tx_Buffer,(uint8_t)USART1->TDR);
        p_data++;
        while(!(USART1->ISR & 0x00000080));
	}
}
int Wait_for (char *string)
{
	int so_far =0;
	int len = strlen (string)-1;

	uint8_t data;
	cycleBufPop(H_Rx_Buffer, &data);

	while(so_far < len && !cycleBufEmpty(H_Rx_Buffer)){
		if (data != string[so_far])
			{
				so_far =0;
				cycleBufPop(H_Rx_Buffer, &data);
			}
		else{
			so_far++;
			cycleBufPop(H_Rx_Buffer, &data);
		}
	}
	if (so_far == len) {
		return 1;
	}
	else{
		cycleBufFree(H_Rx_Buffer);
		cycleBufReset(H_Rx_Buffer);
		return -1;
	}

}
int Wait_for2 (char *string)
{
	int so_far =0;
	int len = strlen (string)-1;

	uint8_t data;
	cycleBufPop(H_Rx_Buffer, &data);

	while(so_far < len && !cycleBufEmpty(H_Rx_Buffer)){
		if (data != string[so_far])
			{
				so_far =0;
				cycleBufPop(H_Rx_Buffer, &data);
			}
		else{
			so_far++;
			cycleBufPop(H_Rx_Buffer, &data);
		}
	}
	if (so_far == len) {
		cycleBufFree(H_Rx_Buffer);
		cycleBufReset(H_Rx_Buffer);
		return 1;
	}
	else{
		cycleBufFree(H_Rx_Buffer);
		cycleBufReset(H_Rx_Buffer);
		return -1;
	}}
int Wait_for3 (char *string)
{
	int so_far =0;
	int len = strlen (string)-1;
	int counter=0;
	int limit = UART_BUFFER_SIZE;
	while(so_far < len && counter<limit){
		if ((int)A_Rx_Buffer[counter] != string[so_far])
			{
				so_far =0;
				counter++;
			}
		else{
			so_far++;
			counter++;
		}
	}
	if (so_far == len) {
		cycleBufFree(H_Rx_Buffer);
		cycleBufReset(H_Rx_Buffer);
		return 1;
	}
	else{

		return -1;

}
}

int checkMatch (char *string)
{
	int so_far =0;
	int len = strlen (string)-1;
	int counter=0;
	int limit = UART_BUFFER_SIZE;
	while(so_far < len && counter<limit){
		if ((int)A_Rx_Buffer[counter] != string[so_far])
			{
				so_far =0;
				counter++;
			}
		else{
			so_far++;
			counter++;
		}
	}
	if (so_far == len) {
		return 1;
	}
	else{

		return -1;
	}
}

//helper function
//append char to array of chars
int  append(char*s, size_t size, char c) {
     int len = strlen(s);
     s[len] = c;
     s[len+1] = '\0';
     return 0;
}

void getIp(){
	char  ip[20]="";
	int so_far =0;
	char * string ="\"";
	int len = strlen (string);
	uint8_t data;
	cycleBufPop(H_Rx_Buffer, &data);

	while(so_far < len && !cycleBufEmpty(H_Rx_Buffer)){
		if (data != string[so_far])
			{
				so_far =0;
			    strncat(ip,&data, 1);
			    cycleBufPop(H_Rx_Buffer, &data);
			}
		else{
			so_far++;
			cycleBufPop(H_Rx_Buffer, &data);
		}
	}
	if (so_far == len) {
			char data[80];
			sprintf (data, "IP ADDR: %s\n\n",ip);
			USART2_print(data);
			cycleBufFree(H_Rx_Buffer);
			cycleBufReset(H_Rx_Buffer);
	}


}









