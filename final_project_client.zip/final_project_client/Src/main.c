/*****************************************************************************//*
    Created By : Abdallah Natsheh , Ameer Haddad
    Client Final Project
*//*****************************************************************************/
#include "stm32f303xe.h"
#include "usart1.h"
#include "usart2.h"
#include "esp8266.h"
#include "types.h"
#include "button.h"
#include "led.h"
#include "event_queue.h"
#include "iwdg.h"
#include "terminal.h"
#include "timer2.h"
#include "scheduler.h"


int main(void)
{
	char  ssid[32];
	char  passwd[64];
	char  serverIp[64];

	USART2_Init();
	USART1_Init();
	USART2_print("Welcome Client!\n\n");
	 //wait 10 sec to enter ssid
	iwdg_init(IWDG_PR_DIV_256,3349999);
	setSSID(ssid);
    iwdg_feed();
	//wait 10 sec to enter password
	setPASSWD(passwd);
    iwdg_feed();
	//wait 10 sec to enter server ip
	setServerIP(serverIp);
    iwdg_feed();

	eventQueueInit();
	NVIC_EnableIRQ(USART2_IRQn);
	//WAIT NEARLY 22 SECOND THEN RESTART big preloader for the long time to wait
	iwdg_init(IWDG_PR_DIV_256,3349999);
	espInit(ssid,passwd,serverIp);
    LED_init();
    BUTTON_init();


    while (1){
    	eventProcess();
        iwdg_feed();
        if(USART2_commandReceived())
        {
            TERMINAL_handleCommand();
        }

        if(USART1_commandReceived())
        {
            TERMINAL_handleCommand();
        }
        if(TIMER2_expired())
        {
        	SCHEDULER_handle();
        }
    };
}

