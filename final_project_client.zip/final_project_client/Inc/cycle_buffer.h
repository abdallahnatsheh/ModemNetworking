#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <assert.h>
#include <stdbool.h>

#ifndef CYCLE_BUFFER_H_
#define CYCLE_BUFFER_H_
/******************************************************************************
Definitions
******************************************************************************/
#define UART_BUFFER_SIZE 128

/******************************************************************************
Exported functions
******************************************************************************/


//  cycle buffer struct
typedef struct cycle_buf_t cycle_buf_t;

// Handle to interact with cycle vuffer
typedef cycle_buf_t* cbuf_handle_t;
/******************************************************************************
cycleBufInit
Description: Initializes the cycle buffer .
Input :  storage buffer and size
Return : cycle buffer handle
******************************************************************************/
cbuf_handle_t cycleBufInit(uint8_t* buffer, size_t size);
/******************************************************************************
cycleBufFree
Description: free the cycle buffer
Input :  cycle buffer handler
******************************************************************************/
void cycleBufFree(cbuf_handle_t cbuf);
/******************************************************************************
cycleBufReset
Description: Reset the cycle buffer to empty, head == tail.
Input :  cycle buffer handler
******************************************************************************/
void cycleBufReset(cbuf_handle_t cbuf);
/******************************************************************************
cycleBufPush
Description: add data to the cycle buffer and overwrite old data
Input :  cycle buffer handler , data to push
******************************************************************************/
void cycleBufPush(cbuf_handle_t cbuf, uint8_t data);
int cycleBufPush2(cbuf_handle_t cbuf, uint8_t data);
/******************************************************************************
cycleBufPop
Description: add data to the cycle buffer and overwrite old data
Input :  cycle buffer handler , address to pop the data into
Return:  0 on success, -1 if the buffer is empty
******************************************************************************/
int cycleBufPop(cbuf_handle_t cbuf, uint8_t * data);
/******************************************************************************
cycleBufPop
Description: Checks if cycle  buffer is empty
Input :  cycle buffer handler
Return:    true if the buffer is empty
******************************************************************************/
bool cycleBufEmpty(cbuf_handle_t cbuf);
/******************************************************************************
cycleBufFull
Description: Checks if cycle  buffer is full
Input :  cycle buffer handler
Return:    true if the buffer is full
******************************************************************************/
bool cycleBufFull(cbuf_handle_t cbuf);


#endif //CYCLE_BUFFER_H_
