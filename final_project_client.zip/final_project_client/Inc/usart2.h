#ifndef USART2_H_
#define USART2_H_
/******************************************************************************
Includes
******************************************************************************/
#include "types.h"

/******************************************************************************
Definitions
******************************************************************************/
#define USART2_SIZE_OF_RX_BUFFER 128


/******************************************************************************
Exported functions
******************************************************************************/

/******************************************************************************
USART2_init
Description: Initializes USART2 on GPIOs PA2 and PA3,
  with a baud rate of 9600.
******************************************************************************/
void USART2_Init(void);
/******************************************************************************
usart2EventHandler
Description: Handle usart2  event from event queue.
******************************************************************************/
void usart2EventHandler();
/******************************************************************************
USART2_print
Description: Prints a '\0'-terminated sequence of characters.
Input:
  p_data: The sequence to print.
******************************************************************************/
void USART2_print(const char *p_data);
/******************************************************************************
USART2_printCharacter
Description: Prints one character.
Input:
  c: The character to print.
******************************************************************************/
void USART2_printCharacter(char c);
/******************************************************************************
USART2_getCommand
Description:check if a command is received in usart2 rx
Input:
  string: the command to check if exist in rx usart2
******************************************************************************/
int USART2_getCommand (char *string);
/******************************************************************************
USART2_commandReceived
Description: check if usart2 recieved a command.
******************************************************************************/
BOOL USART2_commandReceived(void);
#endif /* USART2_H_ */
