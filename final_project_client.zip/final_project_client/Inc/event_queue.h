#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <assert.h>
#include <stdbool.h>

#ifndef EVENT_QUEUE_H_
#define EVENT_QUEUE_H_
/******************************************************************************
Definitions
******************************************************************************/
#define EVENT_BUFFER_SIZE 128

typedef enum {
	EVENT_BUTTON=5,
	EVENT_USART2=6,
	EVENT_USART1=7
} EVENT;
/******************************************************************************
Exported functions
******************************************************************************/
/******************************************************************************
eventQueueInit
Description: Initializes event queue
******************************************************************************/
void eventQueueInit();

/******************************************************************************
addEvent
Description: add event to the event queue
input : event from interrupts
******************************************************************************/
void addEvent(EVENT event);
/******************************************************************************
eventProcess
Description: process the events from event queue
******************************************************************************/
void eventProcess();







#endif //EVENT_QUEUE_H_
