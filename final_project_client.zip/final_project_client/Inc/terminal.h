#ifndef TERMINAL_H_
#define TERMINAL_H_




/******************************************************************************
TERMINAL_handleCommand
Description: Fetches a command from the USART1/2 RX cycle buffer and executes
it after checking the command in the RX cycle buffer
Note:
  The function assumes there is a command in the buffer.
******************************************************************************/
void TERMINAL_handleCommand(void);




#endif /* TERMINAL_H_ */
